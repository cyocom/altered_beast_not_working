require File.dirname(__FILE__) + '/../spec_helper'

describe SitesHelper do # Helper methods can be called directly in the examples (it blocks)
end
